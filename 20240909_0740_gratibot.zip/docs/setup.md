python -m venv venv
source venv
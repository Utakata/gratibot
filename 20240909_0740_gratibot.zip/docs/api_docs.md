from linebot import LineBotApi
from linebot.models import TextSendMessage

line_bot_api = LineBotApi('YOUR_CHANNEL_ACCESS_TOKEN')

@app.route("/callback", methods=['POST'])
def callback():
    # Webhook からのリクエストを処理
    # 感謝メッセージを受け取る
    message = request.json['events'][0]['message']['text']
    user_id = request.json['events'][0]['source']['userId']
    
    # 感謝メッセージを処理（Gemini APIへ送信
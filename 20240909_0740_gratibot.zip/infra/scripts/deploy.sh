#!/bin/bash

# deploy.sh
# アプリケーションをデプロイするためのシェルスクリプト

set -e  # エラーが発生した場合にスクリプトを終了

# 環境変数の設定
APP_NAME="gratibot"
DEPLOY_DIR="/var/www/${APP_NAME}"
REPO_URL="https://github.com/yourusername/${APP_NAME}.git"
BRANCH="main"

# 関数: ログ出力
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1"
}

# 関数: 依存関係のインストール
install_dependencies() {
    log "依存関係をインストールしています..."
    npm install
}

# 関数: アプリケーションのビルド
build_app() {
    log "アプリケーションをビルドしています..."
    npm run build
}

# 関数: アプリケーションの再起動
restart_app() {
    log
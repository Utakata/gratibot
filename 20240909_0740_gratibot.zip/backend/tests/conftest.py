import pytest
import asyncio
from typing import AsyncGenerator
from httpx import AsyncClient
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from cryptography.fernet import Fernet

from app.main import app
from app.database import Base, get_db
from app.config import settings
from app.auth import create_access_token

# テスト用の非同期データベースエンジンを作成
test_async_engine = create_async_engine(settings.TEST_DATABASE_URL, echo=True, future=True)
TestingSessionLocal = sessionmaker(
    test_async_engine, class_=AsyncSession, expire_on_commit=False
)

# 暗号化キーの生成（実際の運用では環境変数から取得すべき）
encryption_key = Fernet.generate_key()
fernet =
import asyncio
import unittest
from unittest.mock import AsyncMock, patch
from typing import Dict, Any
from aiohttp import ClientSession
from cryptography.fernet import Fernet
from backend.services.gemini_service import GeminiService
from backend.models.user import User
from backend.config import Config

class TestGeminiService(unittest.TestCase):
    def setUp(self):
        self.config = Config()
        self.encryption_key = Fernet.generate_key()
        self.fernet = Fernet(self.encryption_key)
        self.gemini_service = GeminiService(self.config, self.fernet)

    @patch('backend.services.gemini_service.ClientSession')
    async def test_analyze_gratitude_post(self, mock_session):
        # モックの設定
        mock_response = AsyncMock()
        mock_response.json.return_value = {
            "analysis": "This is a heartfelt gratitude post.",
            "sentiment": "positive"
        }
        mock_session.return_value.__aenter__.return_value.post.return_value.__aenter__.return_value = mock_response

        # テストデータ
        user =
import asyncio
import unittest
from unittest.mock import AsyncMock, patch
from typing import Dict, Any

from backend.sheets import SheetsManager
from backend.config import Config
from backend.encryption import encrypt_data, decrypt_data

class TestSheetsManager(unittest.TestCase):
    def setUp(self):
        self.config = Config()
        self.sheets_manager = SheetsManager(self.config)

    @patch('backend.sheets.build')
    async def test_authenticate(self, mock_build):
        mock_build.return_value = AsyncMock()
        await self.sheets_manager.authenticate()
        mock_build.assert_called_once_with('sheets', 'v4', credentials=self.sheets_manager.credentials)

    @patch('backend.sheets.SheetsManager.authenticate')
    @patch('backend.sheets.SheetsManager._get_sheet_id')
    async def test_save_gratitude(self, mock_get_sheet_id, mock_authenticate
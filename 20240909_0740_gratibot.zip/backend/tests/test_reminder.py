import asyncio
import unittest
from unittest.mock import AsyncMock, patch
from datetime import datetime, timedelta
from typing import List, Dict, Any

from backend.models.reminder import Reminder
from backend.services.reminder_service import ReminderService
from backend.utils.encryption import encrypt_data, decrypt_data
from backend.utils.oauth2 import verify_token
from backend.utils.gemini_api import analyze_content
from backend.utils.spreadsheet import save_to_spreadsheet
from backend.utils.line_bot import send_reminder_message

class TestReminder(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.reminder_service = ReminderService()
        self.test_user_id = "test_user_123"
        self.test_token = "valid_oauth2_token"

    @patch('backend.utils.oauth2.verify_token')
    async def test_create_reminder(self, mock_verify_token: AsyncMock) -> None:
        mock_verify_token.return_value = True

        reminder_data = {
            "user_id": self.test_user_id,
            "message": "Remember to be grateful!",
            "
import asyncio
import unittest
from unittest.mock import AsyncMock, patch
from typing import Dict, Any

from aiohttp import web
from aiohttp.test_utils import AioHTTPTestCase, unittest_run_loop

from backend.line_bot import LineBotHandler
from backend.models import User, GratitudePost
from backend.security import encrypt_data, decrypt_data
from backend.gemini_api import GeminiAPI
from backend.google_sheets import GoogleSheetsAPI

class TestLineBotHandler(AioHTTPTestCase):
    async def get_application(self) -> web.Application:
        app = web.Application()
        app['line_bot'] = LineBotHandler(
            channel_secret='test_secret',
            channel_access_token='test_token'
        )
        return app

    @unittest_run_loop
    async def test_handle_message_event(self):
        mock_event = AsyncMock()
        mock_event.message.text = "感謝します：同僚の山田さんが助けてくれ
# app/utils/__init__.py

"""
このモジュールには、アプリケーション全体で使用される
ユーティリティ関数とヘルパーが含まれています。
"""

# 必要に応じて、このディレクトリ内の他のモジュールからインポートを行います
# from .date_utils import format_date
# from .string_utils import sanitize_input
# from .validation_utils import validate_email

# このモジュールから直接エクスポートしたい関数がある場合は、
# 以下のように__all__リストに追加します
__all__ = [
    # 'format_date',
    # 'sanitize_input',
    # 'validate_email',
]

# 将来的に共通で使用される可能性のある関数や定数を
# ここに直接定義することもできます

def is_production():
    """
    現在の環境が本番環境かどうかを判断します。
    
    Returns:
        bool:
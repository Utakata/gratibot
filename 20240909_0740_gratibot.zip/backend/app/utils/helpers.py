import re
from datetime import datetime
from typing import Any, Dict, List, Union

def sanitize_input(input_string: str) -> str:
    """
    ユーザー入力を安全にサニタイズする関数
    
    Args:
        input_string (str): サニタイズする入力文字列
    
    Returns:
        str: サニタイズされた文字列
    """
    # HTMLタグを除去
    sanitized = re.sub(r'<[^>]*?>', '', input_string)
    # 特殊文字をエスケープ
    sanitized = sanitized.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    return sanitized

def format_date(date: datetime, format_string: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    日付を
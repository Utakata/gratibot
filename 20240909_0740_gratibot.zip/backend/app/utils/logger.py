import logging
import os
from logging.handlers import RotatingFileHandler

def setup_logger(name, log_file, level=logging.INFO):
    """
    ロガーのセットアップを行う関数

    :param name: ロガーの名前
    :param log_file: ログファイルのパス
    :param level: ログレベル（デフォルトはINFO）
    :return: 設定されたロガーオブジェクト
    """
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # ファイルハンドラの設定
    file_handler = RotatingFileHandler(log_file, maxBytes=10*1024*1024, backupCount=5)
    file_handler.setFormatter(formatter)
    file_handler.setLevel(level)

    # コンソールハン
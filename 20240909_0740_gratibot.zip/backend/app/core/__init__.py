# app/core/__init__.py

# サブモジュールのインポート
from .config import settings
from .database import get_db
from .security import create_access_token, verify_access_token

# バージョン情報
__version__ = "1.0.0"

# アプリケーション名
APP_NAME = "GratiBot"

# 初期化関数
def init_app():
    """
    アプリケーションの初期化を行う関数
    """
    # ここに初期化のロジックを追加
    pass

# エクスポートする要素
__all__ = [
    "settings",
    "get_db",
    "create_access_token",
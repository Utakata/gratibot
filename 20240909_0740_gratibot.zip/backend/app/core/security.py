from datetime import datetime, timedelta
from typing import Optional

from jose import jwt
from passlib.context import CryptContext
from pydantic import SecretStr

# セキュリティ設定
SECRET_KEY = "YOUR_SECRET_KEY_HERE"  # 実際の使用時は環境変数から取得するべきです
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# パスワードハッシュ化のためのコンテキスト
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    プレーンテキストのパスワードとハッシュ化されたパスワードを比較します。
    
    :param plain_password: プレーンテキストのパスワード
    :param
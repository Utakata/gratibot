import asyncio
from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import OAuth2PasswordBearer
from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware
from starlette.middleware.cors import CORSMiddleware
from app.line_bot import LineBotHandler
from app.gemini_api import GeminiAPI
from app.google_sheets import GoogleSheetsAPI
from app.reminder import ReminderService
from app.encryption import encrypt_data, decrypt_data
from app.models import User, GratitudePost
from app.database import get_db
from app.config import Settings
from typing import List
import logging
import ssl

# ロギングの設定
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# アプリケーションの設定
settings = Settings()

# FastAPIアプリケーションの初期化
app = FastAPI(title="Gratibot", version="1.0.0")

# HTTPSリダイレクトの強制
app.add_middleware(HTTPSRedirectMiddleware)

# CORSの設定
app.add_middleware(
    CORSMiddleware,
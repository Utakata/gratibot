# app/models/__init__.py

# データモデルのインポート
from .user import User
from .gratitude import Gratitude
from .team import Team

# 必要に応じて他のモデルもインポート
# from .other_model import OtherModel

# モデルの初期化や設定を行う関数（必要に応じて）
def init_models():
    # ここでモデルの初期化や設定を行う
    pass

# 外部からインポート可能なオブジェクトやクラスのリスト
__all__ = ['User', 'Gratitude', 'Team']
"""
Gemini API initialization module.

This module initializes the Gemini API client and provides necessary configurations
for interacting with the Gemini AI model.
"""

import os
from google.generativeai import GenerativeModel, configure

# Configure the Gemini API
API_KEY = os.environ.get("GEMINI_API_KEY")
if not API_KEY:
    raise ValueError("GEMINI_API_KEY environment variable is not set")

configure(api_key=API_KEY)

# Initialize the Gemini model
# You can adjust the model name based on the specific Gemini model you want to use
GEMINI_MODEL = GenerativeModel("gemini-pro")

def get_gemini_model():
    """
    Returns the initialized Gemini model instance.

    Returns:
        GenerativeModel: An instance of the Gemini model.
    """
    return GEMINI_MODEL

# You
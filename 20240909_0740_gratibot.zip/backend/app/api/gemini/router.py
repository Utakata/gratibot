from fastapi import APIRouter, Depends, HTTPException
from typing import Dict
from app.services.gemini_service import GeminiService
from app.models.gemini_models import GeminiRequest, GeminiResponse
from app.core.auth import get_current_user
from app.core.config import settings

router = APIRouter()

@router.post("/generate", response_model=GeminiResponse)
async def generate_content(
    request: GeminiRequest,
    current_user: Dict = Depends(get_current_user),
    gemini_service: GeminiService = Depends(GeminiService)
):
    """
    Generate content using Gemini AI model.
    """
    try:
        response = await gemini_service.generate_content(request.prompt)
        return GeminiResponse(content=response)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@
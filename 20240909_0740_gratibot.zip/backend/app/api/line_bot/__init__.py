# -*- coding: utf-8 -*-

"""
LINE Bot API initialization file.
This module sets up the necessary components for interacting with the LINE Bot API.
"""

from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import (
    MessageEvent, TextMessage, TextSendMessage,
    FollowEvent, UnfollowEvent, JoinEvent, LeaveEvent
)

# Import environment variables
from app.core.config import settings

# Initialize LINE Bot API client
line_bot_api = LineBotApi(settings.LINE_CHANNEL_ACCESS_TOKEN)

# Initialize WebhookHandler
webhook_handler = WebhookHandler(settings.LINE_CHANNEL_SECRET)

# Import route handlers
from .routes import router

# Import event handlers
from . import event_handlers

__all__ = [
    'line_bot_api',
    'webhook_handler',
    'router',
    'InvalidSignatureError',
    'MessageEvent',
    
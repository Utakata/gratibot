"""
Google Sheets API initialization and utility functions.

This module provides the necessary setup and utility functions for interacting
with the Google Sheets API in the Gratibot application.
"""

from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
import os

# Scopes required for Google Sheets API
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

def get_sheets_service():
    """
    Initialize and return a Google Sheets API service object.

    Returns:
        A Google Sheets API service object.

    Raises:
        FileNotFoundError: If the service account key file is not found.
        ValueError: If required environment variables are not set.
    """
    # Path to the service account key file
    key_path = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
    
    if not key_path:
        raise ValueError("GOOGLE_APPLICATION_CREDENTIALS environment variable is not set")
    
    if not os.path.exists(key_path):
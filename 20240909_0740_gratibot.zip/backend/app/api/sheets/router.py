from fastapi import APIRouter, Depends, HTTPException
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from typing import List, Dict

from app.core.config import settings
from app.core.security import get_current_user
from app.schemas.sheet import SheetData
from app.services.google_sheets import GoogleSheetsService

router = APIRouter()

@router.get("/sheets", response_model=List[Dict[str, str]])
async def list_sheets(current_user: dict = Depends(get_current_user)):
    """
    List all available Google Sheets for the authenticated user.
    """
    try:
        service = GoogleSheetsService(current_user["google_token"])
        sheets = service.list_sheets()
        return sheets
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing sheets: {str(e)}")

@router.get("/sheets/{sheet_id}", response_model
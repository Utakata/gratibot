import os
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import (
    MessageEvent, TextMessage, TextSendMessage,
    TemplateSendMessage, ButtonsTemplate, URIAction
)

class LineService:
    def __init__(self):
        self.line_bot_api = LineBotApi(os.environ.get('LINE_CHANNEL_ACCESS_TOKEN'))
        self.handler = WebhookHandler(os.environ.get('LINE_CHANNEL_SECRET'))

    def handle_webhook(self, body, signature):
        try:
            self.handler.handle(body, signature)
            return True
        except InvalidSignatureError:
            return False

    @handler.add(MessageEvent, message=TextMessage)
    def handle_message(self, event):
        text = event.message.text
        
        if text == "ヘルプ":
            self.send_help_message(event.reply_token)
        else:
            self.send_text_message(event.reply_token, f"あなたが
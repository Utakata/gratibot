from datetime import datetime, timedelta
from typing import List, Dict
from sqlalchemy.orm import Session
from app.models.reminder import Reminder
from app.models.user import User
from app.schemas.reminder import ReminderCreate, ReminderUpdate
from app.utils.notification import send_notification

class ReminderService:
    def __init__(self, db: Session):
        self.db = db

    def create_reminder(self, reminder: ReminderCreate, user_id: int) -> Reminder:
        """
        新しいリマインダーを作成します。
        """
        db_reminder = Reminder(**reminder.dict(), user_id=user_id)
        self.db.add(db_reminder)
        self.db.commit()
        self.db.refresh(db_reminder)
        return db_reminder

    def get_reminder(self, reminder_id: int) ->
import os
from typing import List, Optional
import google.generativeai as genai
from google.generativeai.types import GenerateContentResponse
from dotenv import load_dotenv

# 環境変数を読み込む
load_dotenv()

# Gemini API キーを環境変数から取得
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Gemini API の設定
genai.configure(api_key=GEMINI_API_KEY)

class GeminiService:
    def __init__(self):
        self.model = genai.GenerativeModel('gemini-pro')

    async def generate_text(self, prompt: str, max_tokens: int = 1000) -> str:
        """
        指定されたプロンプトに基づいてテキストを生成します。

        :param prompt: 生成のためのプロン
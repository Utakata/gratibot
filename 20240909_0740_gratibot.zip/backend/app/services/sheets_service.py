import os
from typing import List, Dict, Any
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

class SheetsService:
    def __init__(self):
        self.creds = None
        self.service = None
        self._authenticate()

    def _authenticate(self):
        """Google Sheets APIの認証を行う"""
        # 環境変数から認証情報を取得
        creds_json = os.getenv('GOOGLE_CREDENTIALS')
        if not creds_json:
            raise ValueError("Google認証情報が設定されていません")

        self.creds = Credentials.from_authorized_user_file(creds_json, ['https://www.googleapis.com/auth/spreadsheets'])
        self.service = build('sheets', 'v4', credentials=self.creds)

    def read_sheet(self, spreadsheet_id: str, range_name: str) -> List[List[Any]]:
        """
        指定されたスプ
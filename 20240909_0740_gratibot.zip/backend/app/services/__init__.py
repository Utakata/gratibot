# __init__.py

"""
このモジュールはサービスレイヤーの初期化ファイルです。
サービスレイヤーは、アプリケーションのビジネスロジックを含む重要な部分です。
"""

# 必要なサービスモジュールをインポートします
from .user_service import UserService
from .auth_service import AuthService
from .gratibot_service import GratibotService

# サービスのインスタンスを作成します
user_service = UserService()
auth_service = AuthService()
gratibot_service = GratibotService()

# 他のモジュールからインポートされる可能性のあるサービスをここで定義します
__all__ = ['user_service', 'auth_service', 'gratibot_service']
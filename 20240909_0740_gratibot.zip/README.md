   git clone https://github.com/your-org/gratibot.git
   cd gratibot
   npm install
   cp .env.example .env
   npm start